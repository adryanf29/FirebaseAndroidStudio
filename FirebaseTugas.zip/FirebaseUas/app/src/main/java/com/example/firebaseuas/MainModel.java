package com.example.firebaseuas;

public class MainModel {
    String nama,prodi,email,turl;

    MainModel()
    {

    }
    public MainModel(String nama, String prodi, String email, String turl) {
        this.nama = nama;
        this.prodi = prodi;
        this.email = email;
        this.turl = turl;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getProdi() {
        return prodi;
    }

    public void setProdi(String prodi) {
        this.prodi = prodi;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTurl() {
        return turl;
    }

    public void setTurl(String turl) {
        this.turl = turl;
    }
}
